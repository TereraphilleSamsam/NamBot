const Discord = require('discord.js');

// Access required classes using dot notation
const client = new Discord.Client({
  intents: [
    Discord.IntentsBitField.Flags.Guilds,
    Discord.IntentsBitField.Flags.GuildMessages,
    Discord.IntentsBitField.Flags.MessageContent
  ]
});

// Your bot token (make sure to keep it secret)
const token = 'MTM0NTU2MDEzMTc4NTU4ODg0Nw.GjJUTt.Hzbw4Kaq5Rz5V11Cu4hZz9l8ViWmXfLkjKIZM0';

client.once('ready', () => {
  console.log(`Bot is online as ${client.user.tag}`);
});

client.on('messageCreate', message => {
  if (message.author.bot) return;

  if (message.content === '!hello') {
    message.channel.send('Hey there!');
  }
});

client.login(token);